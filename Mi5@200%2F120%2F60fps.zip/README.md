# Magisk Module Template

This adds Camera libhacks to Mi 5s. 
credits: @defcomq(k), Tadi, WG

